package ex1;

public class ConstValues {
    public static final double g_const = 9.81;
    public static final int numberOfRecord = 100000;
    public static final int blockingFactor = 100;
    public static final int numberOfBuffers = 100;
    public static final int blockSize = blockingFactor*12;
    public static final int minRangeRecord = 1;
    public static final int maxRangeRecord = 99;
    public static final boolean printFile = true;
    public static boolean printRuns = true;
    public static final int numberOfLinesToPrint = 500;
}
